TCP chat is working with variable amount of recipients for sending messages.

UDP chat is not working
